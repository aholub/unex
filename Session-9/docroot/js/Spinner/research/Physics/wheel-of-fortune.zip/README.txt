A Pen created at CodePen.io. You can find this one at http://codepen.io/zadvorsky/pen/xzhBw.

 Making one of these is harder than I thought it would be, but here's version 1.0

Powered by p2 physics.

Go on, give it a spin.